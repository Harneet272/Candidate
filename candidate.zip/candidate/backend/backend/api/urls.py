from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import QuestionViewSet, CandidateViewSet, CandidateAnswerViewSet, DepartmentViewSet,create_candidate_and_assign, get_candidate_questions, submit_test
from . import views
from .views import download_ai_report
from .views import admin_login

router = DefaultRouter()
router.register(r'questions', QuestionViewSet)
router.register(r'candidates', CandidateViewSet)
router.register(r'answers', CandidateAnswerViewSet)
router.register(r'departments',DepartmentViewSet) 
urlpatterns = [
    path('', include(router.urls)),
    path('create-candidate/', create_candidate_and_assign),
    path('candidate-questions/<int:candidate_id>/', get_candidate_questions),
    path('submit-test/', submit_test),  # ✅ Correct path for frontend
    path('is-submitted/<int:candidate_id>/', views.is_test_submitted),
    path('download-report/<int:candidate_id>/', download_ai_report, name='download-ai-report'),
      path('admin-login/', views.admin_login, name='admin-login'),
]
