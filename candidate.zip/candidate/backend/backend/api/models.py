from django.db import models
from ckeditor.fields import RichTextField


class Department(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Question(models.Model):
    question_text = RichTextField()
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    question_order = models.IntegerField()
    question_type = models.CharField(max_length=50, default='text')


    class Meta:
        unique_together = ('department', 'question_order')  # ✅ Allows same order for different departments

    def __str__(self):
        return f"{self.question_order} -  {self.department.name}"


class Candidate(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    position = models.CharField(max_length=100)
    address = models.CharField(max_length=100, default='N/A')
    department = models.ForeignKey(Department, on_delete=models.SET_NULL, null=True)
    is_submitted = models.BooleanField(default=False) 
    report_link = models.CharField(max_length=255, blank=True, null=True)  # 🆕 NEW FIELD

    def __str__(self):
        return self.name


class CandidateAnswer(models.Model):
    candidate = models.ForeignKey(Candidate, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    text_answer = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Answer by {self.candidate.name} for Question {self.question.question_order}"
