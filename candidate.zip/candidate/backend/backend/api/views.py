from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import viewsets
from .models import Candidate, Question, CandidateAnswer, Department
from .serializers import CandidateSerializer, QuestionSerializer, CandidateAnswerSerializer
from rest_framework.parsers import MultiPartParser, FormParser
import json
from rest_framework.decorators import parser_classes
from .ai import generate_ai_report
from django.http import FileResponse
import os
from .serializers import DepartmentSerializer
from django.contrib.auth import authenticate, login
from rest_framework.decorators import api_view, permission_classes
from django.conf import settings
from rest_framework.permissions import AllowAny

@api_view(['POST'])
def admin_login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    user = authenticate(username=username, password=password)

    if user is not None and user.is_staff:
        return Response({"success": True, "message": "Login successful"})
    elif user is not None and not user.is_staff:
        return Response({"success": False, "message": "User is not authorized (not admin)"})
    else:
        return Response({"success": False, "message": "Invalid credentials"})

@api_view(['POST'])
def create_candidate_and_assign(request):
    department_name = request.data.get('department')
    try:
        department_obj = Department.objects.get(name=department_name)
    except Department.DoesNotExist:
        return Response({"error": "Department not found"}, status=400)

    candidate = Candidate.objects.create(
        name=request.data.get('name'),
        email=request.data.get('email'),
        phone=request.data.get('phone'),
        address=request.data.get('address'),
        position=request.data.get('position'),
        department=department_obj
    )

    test_link = f"http://localhost:3000/test/{candidate.id}"
    return Response({"test_link": test_link, "candidate_id": candidate.id})


@api_view(['GET'])
def get_candidate_questions(request, candidate_id):
    try:
        candidate = Candidate.objects.get(id=candidate_id)
        questions = Question.objects.filter(department=candidate.department)
        serializer = QuestionSerializer(questions, many=True)
        return Response(serializer.data)
    except Candidate.DoesNotExist:
        return Response({"error": "Candidate not found"}, status=404)


@api_view(['POST'])
@parser_classes([MultiPartParser, FormParser])
def submit_test(request):
    try:
        responses_data = request.data.get('responses')

        if not responses_data:
            return Response({"error": "Missing responses"}, status=400)

        responses = json.loads(responses_data)

        for response in responses:
            candidate = Candidate.objects.get(id=int(response['candidate_id']))
            question = Question.objects.get(id=int(response['question_id']))
            text_answer = response.get('answer_text', '')

            CandidateAnswer.objects.create(
                candidate=candidate,
                question=question,
                text_answer=text_answer
            )

        # ✅ Mark test submitted
        candidate.is_submitted = True
        candidate.save()

        # ✅ Generate and save AI Report
        from .ai import generate_ai_report
        report_path = generate_ai_report(candidate.id)

        # ✅ Save report link
        if report_path:
            relative_link = report_path.replace('media/', '')  # Save relative path
            candidate.report_link = relative_link
            candidate.save()

        return Response({"status": "success", "message": "Test submitted successfully."})

    except Exception as e:
        print("Submit Test Error:", str(e))
        return Response({"error": str(e)}, status=500)


@api_view(['GET'])
def is_test_submitted(request, candidate_id):
    try:
        candidate = Candidate.objects.get(id=candidate_id)
        return Response({"is_submitted": candidate.is_submitted})
    except Candidate.DoesNotExist:
        return Response({"error": "Candidate not found"}, status=404)

# ✅ AI Report View
@api_view(['GET'])
def download_ai_report(request, candidate_id):
    try:
        from .ai import generate_ai_report
        report_path = generate_ai_report(candidate_id)

        if report_path and os.path.exists(report_path):
            response = FileResponse(open(report_path, 'rb'), content_type='application/pdf')
            response['Content-Disposition'] = 'inline; filename="AI_Report.pdf"'  # Show in browser
            return response
        else:
            return Response({"error": "Report not found."}, status=404)
    except Exception as e:
        return Response({"error": str(e)}, status=500)
class QuestionViewSet(viewsets.ModelViewSet):
    queryset = Question.objects.all().order_by('question_order')
    serializer_class = QuestionSerializer


class CandidateViewSet(viewsets.ModelViewSet):
    queryset = Candidate.objects.all()
    serializer_class = CandidateSerializer


class CandidateAnswerViewSet(viewsets.ModelViewSet):
    queryset = CandidateAnswer.objects.all()
    serializer_class = CandidateAnswerSerializer
class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer