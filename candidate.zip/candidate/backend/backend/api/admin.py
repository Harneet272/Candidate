# Register your models here.
from django.contrib import admin
from .models import Question, Candidate, CandidateAnswer,Department
class CandidateAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'department', 'position', 'test_link')

    def test_link(self, obj):
        return f"http://localhost:3000/test/{obj.id}"
    test_link.short_description = "Test Link" 


admin.site.register(Question)
admin.site.register(Candidate)
admin.site.register(CandidateAnswer)
admin.site.register(Department)

