from rest_framework import serializers
from .models import Candidate, Question, CandidateAnswer,Department

class CandidateSerializer(serializers.ModelSerializer):
    department = serializers.CharField(source='department.name', read_only=True)

    class Meta:
        model = Candidate
        fields = '__all__'

class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = '__all__'

class CandidateAnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateAnswer
        fields = '__all__'
    extra_kwargs = {
            'audio_answer_file': {'required': False, 'allow_null': True},
            'text_answer': {'required': False, 'allow_null': True}
        }
    
class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = '__all__'