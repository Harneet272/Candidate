import openai
import os
from django.conf import settings
from fpdf import FPDF

# openai.api_type = "azure"
# openai.api_key = settings.AZURE_OPENAI_API_KEY
# openai.api_base = settings.AZURE_OPENAI_ENDPOINT
# openai.api_version = "2024-08-01-preview"  # or check your deployment version


from .models import Candidate, CandidateAnswer

import os
import requests
from django.conf import settings
from .models import Candidate, CandidateAnswer, Question

import os
from dotenv import load_dotenv
load_dotenv()

AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
print("api key",AZURE_OPENAI_API_KEY)
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
print("endpoint",AZURE_OPENAI_ENDPOINT)

def generate_ai_report(candidate_id):
    try:
        candidate = Candidate.objects.get(id=candidate_id)
        answers = CandidateAnswer.objects.filter(candidate=candidate)

        prompt = f"""Generate a professional interview report for the following candidate:
        
    Sections:
1. Overall Summary (Total Score out of 10, Strengths, Weaknesses)
2. Question-wise Evaluation (Question, Candidate's Answer, Score out of 10, Reason for Score)

Note: Please ensure that the score for each answer is rated out of 10.
Candidate Details:
Name: {candidate.name}
Email: {candidate.email}
Phone: {candidate.phone}
Position: {candidate.position}
Department: {candidate.department.name}

Candidate Responses:
"""
        for ans in answers:
            prompt += f"\nQuestion {ans.question.question_order}: {ans.question.question_text}\nAnswer: {ans.text_answer or 'Not answered'}\n"

        headers = {
            "Content-Type": "application/json",
            "api-key": AZURE_OPENAI_API_KEY
        }

        payload = {
            "messages": [
                {"role": "system", "content": "You are a professional HR analyst generating structured interview reports."},
                {"role": "user", "content": prompt.strip()}
            ],
            "temperature": 0.6,
            "top_p": 0.9,
            "max_tokens": 1500
        }

        response = requests.post(AZURE_OPENAI_ENDPOINT, headers=headers, json=payload)

        if response.status_code == 200:
            result = response.json()
            content = result['choices'][0]['message']['content']

            # ➕ Create structured PDF
            pdf = FPDF()
            pdf.add_page()
            pdf.set_auto_page_break(auto=True, margin=15)
            pdf.set_font("Arial", 'B', 16)
            pdf.cell(0, 10, "Candidate HR Evaluation Report", ln=True, align='C')
            pdf.ln(8)

            # Candidate Info Section
            pdf.set_font("Arial", 'B', 14)
            pdf.cell(0, 10, "Section 1: Candidate Information", ln=True)
            pdf.set_font("Arial", '', 12)
            pdf.multi_cell(0, 10, f"""
Name      : {candidate.name}
Email     : {candidate.email}
Phone     : {candidate.phone}
Position  : {candidate.position}
Department: {candidate.department.name}
""".strip())
            pdf.ln(5)

            # Add AI-Generated Report
            pdf.set_font("Arial", 'B', 14)
            pdf.cell(0, 10, "Section 2: Evaluation Summary", ln=True)
            pdf.set_font("Arial", '', 12)
            for line in content.split('\n'):
                clean_line = line.strip().replace("*", "").replace("•", "-")
                if clean_line:
                    pdf.multi_cell(0, 8, clean_line)

            # Save Report
            report_dir = os.path.join(settings.MEDIA_ROOT, 'reports')
            os.makedirs(report_dir, exist_ok=True)
            report_path = os.path.abspath(os.path.join(report_dir, f"{candidate.name}_AI_Report.pdf"))


            pdf.output(report_path)

            # Save report path in candidate
            candidate.report_link = report_path
            candidate.save()

            return report_path

        else:
            print("AI API Error:", response.status_code, response.text)
            return None

    except Exception as e:
        print("AI Report Generation Error:", str(e))
        return None