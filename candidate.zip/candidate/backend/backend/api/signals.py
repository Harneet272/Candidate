from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from .models import Candidate

@receiver(post_save, sender=Candidate)
def send_test_link_email(sender, instance, created, **kwargs):
    if created:  # ✅ Only when a new candidate is created
        test_link = f"http://localhost:3000/test/{instance.id}"
        send_mail(
            subject="Your Test Link - Recruitment System",
            message=f"Hi {instance.name},\n\nHere is your test link:\n{test_link}\n\nGood luck!",
            from_email='harneet302003@gmail.com',
            recipient_list=[instance.email],
            fail_silently=False
        )
